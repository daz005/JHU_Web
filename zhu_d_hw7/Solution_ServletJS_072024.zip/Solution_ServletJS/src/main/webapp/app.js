/**
 * app.js is responsible for checking input types,
 *
 * author Student in Spring 2022 EN605.681
 * author Modifications by RF Spiegel
 *
 * Copyright 2021 : Richard Spiegel and The Johns Hopkins University
 * This code is provided as a reference for students in 605.681 only. 
 * Sharing or use of this code outside of 605.681 in any way (online posting,
 * physical sharing, etc) without the permission of Richard Spiegel
 * is strictly prohibited and would be considered a violation of the 
 * University Academic Misconduct Policy
 * 
 * This code may be used as a baseline for future assignments by students
 * in the class where this was distributed, and it may only
 * be used with 605.681 for the balance of the semester for which it
 * was distributed.  
 */

// client checks to see that num hikers is present and a positive integer only
function validateNumHikers() {
	var numberHikers = parseInt(document.getElementById("numberHikers").value);
	var valid = true;
	if (isNaN(numberHikers)) {
		alert('There is no input for the number of hikers');
		valid = false;
	} else if (!Number.isInteger(numberHikers)) {
		alert('Number of hikers must be an integer');
		valid = false;
	} else if (numberHikers <= 0) {
		alert('Number of hikers must be greater than 0');
		valid = false;		
	}	
	return valid;
}

// check to see that a hike has been selected, never really used
// since the radio buttons assure a selected hike
function validateHikes() {
	var hikeType = document.querySelector('input[name="hikeType"]:checked').value;
	var valid = true;
	if (hikeType.length == 0) {
		alert('A hike must be selected');
		valid = false;
	}		
	return valid;	
}	

// check to see that a year has been entered, that it is and integer that 
// is at least the current year
function validateYear() {
	var year = parseInt(document.getElementById("year").value);
	var thisYear = new Date().getFullYear();
	var valid = true;
	if (isNaN(year)) {
		alert('There is no input for the year');
		valid = false;
	} else if (!Number.isInteger(year)) {
		alert('Year must be an integer');
		valid = false;
	} else if (year < thisYear) {
		alert('Number of hikers must be greater than ' + thisYear );
		valid = false;		
	}	
	return valid;
}

// Check that month field has a value and that it is an integer
// between 1 and 12
function validateMonth() {
	var month = parseInt(document.getElementById("month").value);
	var valid = true;
	if (isNaN(month)) {
		alert('There is no input for the month');
		valid = false;
	} else if (!Number.isInteger(month)) {
		alert('Month must be an integer');
		valid = false;
	} else if (month < 1 || month > 12) {
		alert('Month value must be between 1 and 12');
		valid = false;		
	}		
	return valid;
}

// Check that day field is between 1 and 31 (we won't check for 
// specific months here, let the server handle that for now
function validateDay() {
	var day = parseInt(document.getElementById("day").value);
	var valid = true;
	if (isNaN(day)) {
		alert('There is no input for the starting day');
		valid = false;
	} else if (!Number.isInteger(day)) {
		alert('Starting day must be an integer');
		valid = false;
	} else if (day < 1 || day > 31) {
		alert('Valid days of month must be between 1 and 31' );
		valid = false;		
	}	
	return valid;
}

// Check that duration is present and an integer greater or 
// equal to one.  Let the server handle whether duration is valid
// for selected hike
function validateDuration() {
	var duration = parseInt(document.getElementById("duration").value);
	var valid = true;
	if (isNaN(duration)) {
		alert('There is no input for the hike duration');
		valid = false;
	} else if (!Number.isInteger(duration)) {
		alert('Hike duration must be an integer');
		valid = false;
	} else if (duration < 1) {
		alert('Valid hike durations must be at least 1 day' );
		valid = false;		
	}	
	return valid;
}

// Summary check of all fields on form submission
function validateForm() {
	valid = validateDuration() && validateDay() && validateMonth() && validateYear() && validateHikes() && validateNumHikers();
	return valid;	
}

