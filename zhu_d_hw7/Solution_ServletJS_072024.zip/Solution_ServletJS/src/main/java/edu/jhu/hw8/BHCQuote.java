package edu.jhu.hw8;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.jhu.en605681.HikeType;
import edu.jhu.en605681.Rates;

/**
 * Servlet implementation class BHCQuote, processes five parameters pertaining to hike info (hikeType, year, month,
 * day, duration, and attempts to process a quote for them using QuoteCalculator. Results are displayed below submit
 * button. Previous inputs are saved, with the exception of an invalid HikeType (if input through the URL), for which
 * the program defaults to Navajo Loop
 * 
 * @author Student in Spring 2022 EN605.681
 * @author Significant Updates and Modifications by RF Spiegel
 * 
 * Copyright 2024 : Richard Spiegel and The Johns Hopkins University
 * This version of this code is provided as a reference for students in 605.681 only. 
 * Sharing or use of this code outside of 605.681 in any way (online posting,
 * physical sharing, etc) without the permission of Richard Spiegel
 * is strictly prohibited and would be considered a violation of the 
 * University Academic Misconduct Policy
 * 
 * This code may be used as a baseline for future assignments by students
 * in the class where this was distributed, and it may only
 * be used with 605.681 for the balance of the semester for which it
 * was distributed. 
 */
@WebServlet(name = "BHCQuote", urlPatterns = {"/BHCQuote"})
public class BHCQuote extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
       
    /**
     *  Processes requests for HTTP <code>GET</code> method
     * 
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// if no parameters were provided at all, assume this is from
		// an initial request
		boolean firstVisit = request.getParameterMap().isEmpty();
		// errors tracks whether the page can return with a quote 
		// or if it returns with errors
		boolean errors = false;
		List<String> errorMsgs = new ArrayList<>();
		
        // build hikes list to assemble radio buttons for html page
        String[] hikeList = HikeType.getHikeNames();
        String[] hikeEnums = new String[hikeList.length];
		int i = 0;
		for (String name : hikeList) {
			hikeEnums[i++] = name;
		}          

        // Apply default values for intiial page, first hike and first duration for 
        // that hike.  Date is today and number of hikers is the minimum permitted.
		Rates defaultRate = new Rates(HikeType.values()[0]);
		String hikeType = hikeEnums[0];
		String numberHikers = "1";
        LocalDate today = LocalDate.now();
    	String year = Integer.toString(today.getYear());
    	String month = Integer.toString(today.getMonthValue());
    	String day = Integer.toString(today.getDayOfMonth());
    	String duration = Integer.toString(defaultRate.getDurations()[0]);
       
    	// if not first visit then collect parameters
    	// if any parameters are missing, reassign default for form completion, but collect
    	// errors for output as well
        if (!firstVisit) {
        	if ((hikeType = request.getParameter("hikeType")) == null) {
        		errorMsgs.add("No parameter was sent for the hike type");
        		hikeType = hikeEnums[0];
        	}
        	if ((numberHikers = request.getParameter("numberHikers")) == null) {
        		errorMsgs.add("No parameter was sent for the number of hikers");
        		numberHikers = "1";
        	}
        	if	((year = request.getParameter("year")) == null) {
        		errorMsgs.add("No parameter was sent for the year of the hike");
        		year = Integer.toString(today.getYear());
        	}
        	if ((month = request.getParameter("month")) == null) {
        		errorMsgs.add("No parameter was sent for the month of the hike");
            	month = Integer.toString(today.getMonthValue());
        	}
        	if ((day = request.getParameter("day")) == null) {
        		errorMsgs.add("No parameter was sent for the start day of the hike");
        		day = Integer.toString(today.getDayOfMonth());
        	}
        	if ((duration = request.getParameter("duration")) == null) {
        		errorMsgs.add("No parameter was sent for the hike duration");
        		duration = Integer.toString(defaultRate.getDurations()[0]);
        	}
        	if (errorMsgs.size() > 0)
        		errors = true;
        }        
        
        // Now we have our parameters (default or user provided) and know
        // if we can produce a quote or just errors.
		response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();       
        
        // build form portion of the page
        out.println("<!DOCTYPE html>");
        out.println("<html lang=\"en\">");
        out.println("  <head>");
        out.println("    <meta charset=\"UTF-8\">");
        out.println("    <link href=\"style.css\" rel=\"stylesheet\" type=\"text/css\">");
        out.println("    <title>BHC Hike Booking</title>");
        out.println("    <script src=\"app.js\"></script>");
        out.println("  </head>");
        out.println("  <body class=\"body\">");
        out.println("    <h1>Select a hike and booking timeframe</h1>");     	
        
        out.println("    <form action=\"BHCQuote\" method=\"POST\" onsubmit=\"return validateForm()\">");
        out.println("      <h3>Hike:</h3>");
        // build radio buttons for hikes
        i = 0;
        for (String hike : hikeEnums) {
        	out.print("      <input type=\"RADIO\" class=\"hikeType\" name=\"hikeType\"");
        	// Will check the selected hike for output or the first in the list 
        	// if first visit or missing
        	if (hikeType.equals(hike))
        		out.print(" checked=\"true\"");
        	out.println(" value=\"" + hike + "\" onChange=\"validateHikes()\">" + hikeList[i] + "<br />");
	        i++;
		}
        // number of hikers
        out.println("      <h3>Number of hikers:</h3>");
        out.print("      <input type=\"TEXT\" id=\"numberHikers\" name=\"numberHikers\" value=\"");
        out.print(numberHikers);
        out.println("\" size=\"2\" onfocusout=\"validateNumHikers()\"><br />");
        // Start date, year, month and day fields
        out.println("      <h3>Start date:</h3>");
        out.println("      <label for=\"year\">Year: </label>");
        out.print("      <input type=\"TEXT\" id=\"year\" name=\"year\" value=\"");
        out.print(year);
        out.println("\" size=\"4\" onfocusout=\"validateYear()\"><br />");
        out.println("      <label for=\"month\">Month  (1-12): </label>");
        out.print("      <input type=\"TEXT\" id=\"month\" name=\"month\" value=\"");
        out.print(month);
        out.println("\" size=\"2\" onfocusout=\"validateMonth()\"> <br />");
        out.println("      <label for=\"day\">Day  (1-31): </label>");
        out.print("      <input type=\"TEXT\" id=\"day\" name=\"day\" value=\""); 
        out.print(day); 
        out.println("\" size=\"2\" onfocusout=\"validateDay()\"> <br />");     
        // duration field
        out.println("      <h3>Number of Days:</h3>");
        out.print("      <input type=\"TEXT\" id=\"duration\" name=\"duration\" value =\"");
        out.print(duration);
        out.println("\" size=\"2\" onfocusout=\"validateDuration()\"> <br />");
        
        out.println("      <br /><input id=\"SUBMIT\" type=\"SUBMIT\">");
        out.println("    </form>");
        	
        // print query response based off URL arguments from previous SUBMIT if there are no missing parameters
		if (!firstVisit) {
			if (!errors) {	
				QuoteCalculator qc = new QuoteCalculator();
				ResultObject ro = qc.getQuote(hikeType, month, day, year, duration, numberHikers);
				if (ro.getQuote() == -0.01) {
					out.println("    <h3>The following errors were encountered while processing the quote request:</h3>");
					out.println("    <ul>");
					for (String s : ro.getErrors()) {
						out.println("      <li>" + s + "</li>");
					}
					out.println("    </ul>");
				} else {
					NumberFormat formatter = NumberFormat.getCurrencyInstance();
					String moneyString = formatter.format(ro.getQuote());	
					out.println("    <h3>" + moneyString + "</h3>");					
				}
			} else {
				out.println("    <h3>Quote could not be processed due to the following errors:</h3>");
				out.println("    <ul>");
				for (String s : errorMsgs) {
					out.println("      <li>" + s + "</li>");
				}
				out.println("    </ul>");
			}
		}
        out.println("  </body>");
        out.println("</html>");
	}

    /**
     * Handles the HTTP <code>POST</code> method.
     * Just defers it to GET
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
}
