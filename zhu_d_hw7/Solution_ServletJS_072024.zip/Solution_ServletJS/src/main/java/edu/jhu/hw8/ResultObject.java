package edu.jhu.hw8;

import java.util.ArrayList;
import java.util.List;

/**
 * Sample solution to Desktop UI Assignment: JHU-EP, 605.681.82
 * ResultObject: Utility object to store both quote results and/or
 * 				 associated errors.  
 * 
 * @author RF Spiegel
 * 
 * Copyright 2024 : Richard Spiegel and The Johns Hopkins University
 * This code is provided as a reference for students in 605.681 only. 
 * Sharing or use of this code outside of 605.681 in any way (online posting,
 * physical sharing, etc) without the permission of Richard Spiegel
 * is strictly prohibited and would be considered a violation of the 
 * University Academic Misconduct Policy
 * 
 * This code may be used as a baseline for future assignments by students
 * in the class where this was distributed, and it may only
 * be used with 605.681 for the balance of the semester for which it
 * was distributed. 
 */
public class ResultObject {
	
	private double quote;
	private List<String> errors = new ArrayList<>();

	public ResultObject(double q, List<String> e) {
		super();
		this.quote = q;
		this.errors= e;
	}

	/**
	 * @return the quote
	 */
	public double getQuote() {
		return quote;
	}

	/**
	 * @param quote the quote to set
	 */
	public void setQuote(double quote) {
		this.quote = quote;
	}

	/**
	 * @return the errors
	 */
	public List<String> getErrors() {
		return errors;
	}

	/**
	 * @param errors the errors to set
	 */
	public void setErrors(List<String> errors) {
		this.errors = errors;
	}
}
