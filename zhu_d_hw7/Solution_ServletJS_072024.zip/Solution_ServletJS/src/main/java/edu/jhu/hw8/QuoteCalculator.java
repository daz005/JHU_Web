package edu.jhu.hw8;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import edu.jhu.en605681.BookingDay;
import edu.jhu.en605681.HikeType;
import edu.jhu.en605681.Rates;

/**
 * Sample solution to Desktop UI Assignment: JHU-EP, 605.681.82
 * QuoteCalculator: This is the code where the business logic is
 * 					isolated away from the display.  It takes UI
 * 					inputs, validates them, computes a quote and
 * 					returns the quote and/or errrors.
 * 
 * @author RF Spiegel
 * 
 * Copyright 2024 : Richard Spiegel and The Johns Hopkins University
 * This code is provided as a reference for students in 605.681 only. 
 * Sharing or use of this code outside of 605.681 in any way (online posting,
 * physical sharing, etc) without the permission of Richard Spiegel
 * is strictly prohibited and would be considered a violation of the 
 * University Academic Misconduct Policy
 * 
 * This code may be used as a baseline for future assignments by students
 * in the class where this was distributed, and it may only
 * be used with 605.681 for the balance of the semester for which it
 * was distributed. 
 */
public class QuoteCalculator {
	// Defined as a static constant in the event the value changes in the future
	private static double BAD_QUOTE_VAL = -0.01;
	
	/**
	 * getQuote
	 * 	This is the method that performs the quote computation.
	 * 
	 * @param edu.jhu.en605681.HikeType enum witht he current hike selection
	 * @param java.lang.String dateString which is string representation of the date (MM/DD/YYYY)
	 * @param java.lang.String durString which is a string representation of the hike duration 
	 * @param int value with the number of hikers for the quote
	 * 
	 * @return edu.jhu.en605681.ResultObject with fields for the quote and errors on return
	 */
	public ResultObject getQuote(String hikeString, String monthString, String dayString, String yearString, String durString, String numHikerString) {
		// Interim object to collect multiple error messages that occur outside BhcUtils API
		List<String> errorList = new ArrayList<>();		
		// Flag to indicate that we have errors in the input 
		// parameters that cannot be passed to the BhcUtils classes 
		boolean preQuoteErrors = false;
		int durValue = 0;
		int numHikers = 0;
		
		// Instead of hard coding hikes selected hikes, use the API
		// to determine the selected hike.  This is much more robust
		// to future changes in the API that might add/change/remove
		// potential hikes.
		HikeType hike = HikeType.values()[0];;
		for (HikeType ht : HikeType.values()) {
			if (ht.toString().equals(hikeString)) 
				hike = ht;
		}				
		Rates r = new Rates(hike);
		
		// convert duration string to an integer
		try {
			durValue = Integer.parseInt(durString);
		} catch(NumberFormatException nfe) {
			errorList.add("Bad duration format entered. Try entering a new duration.");
			preQuoteErrors = true;
		}		
		
		// convert number hikers string to an integer
		try {
			numHikers = Integer.parseInt(numHikerString);
		} catch(NumberFormatException nfe) {
			errorList.add("Bad number of hiker format entered. Try entering a new number of hikers.");
			preQuoteErrors = true;
		}		
	
		// Initialize starting date components with
		// current day.  This isn't really necessary
		Calendar c = Calendar.getInstance();
		BookingDay today = new BookingDay(c.get(Calendar.YEAR), c.get(Calendar.MONTH)+1, c.get(Calendar.DAY_OF_MONTH));
		int startMonth = today.getMonth();
		int startDay = today.getDayOfMonth();
		int startYear = today.getYear();		
		
		try {
			startMonth = Integer.parseInt(monthString);
			startDay = Integer.parseInt(dayString);
			startYear = Integer.parseInt(yearString);
		} catch (NumberFormatException nfe) {
			errorList.add("Bad date format entered. Try entering a new start date.");
			preQuoteErrors = true;
		} 
		if (preQuoteErrors) {
			// if there were errors detected before this, the data wouldn't
			// be handled by the BhcUtils so just return the collected errors
			// with a quote value indicating it was bad.
			return new ResultObject(BAD_QUOTE_VAL, errorList);
		} else {
			// Process quote with resulting parameters.  If there are issues
			// with dates, time of year, durations, etc the API can still 
			// return errors.  At this point we collect both and return
			// them to the calling code so it can determine the result and what to
			// do with it.
			BookingDay startDate = new BookingDay(startYear, startMonth, startDay);		
			r.setBeginDate(startDate);
			r.setDuration(durValue);
			r.setNumberHikers(numHikers);				
			double quote = r.getCost();
			return new ResultObject(quote, r.getDetails());
		}
	}
	
}
	
